 //variable for  array of names
let uName = [  ]

//variable for array of marks


let uEngMarks = [ ]
let uMthMarks = [ ]
let uSciMarks  = [ ]
// variable for input boxes / text boxes

let InpFName , InpEngMarks,InpMthMarks,InpSciMarks

// variable for submit button

let btnSubmit

// variable for target Slot
let targetSlot = 0


function setup() {
  createCanvas(400, 400);
 
 
  InpFName = createInput()
  InpFName.position(25, 370)
  InpFName.style("width", "40px")
  
  InpEngMarks = createInput()
  InpEngMarks .position(220, 370)
 InpEngMarks.style("width", "20px")
 
  InpMthMarks = createInput()
  InpMthMarks .position(150, 370)
 InpMthMarks.style("width", "20px")
  
  InpSciMarks = createInput()
  InpSciMarks .position(80, 370)
 InpSciMarks.style("width", "20px")
 
 
 
 
 
  btnSubmit = createButton("SUBMIT")
  btnSubmit.position( 270, 370)
  btnSubmit.style("width", "100px")
  btnSubmit.mousePressed(updateData)
 
}

function draw() {
  background(220);
  
  //display result---------------
 
  for(i=0; i< uName.length ; i++)
    {
      text ( uName[i], 25, 25*i+30 )
      
      
      text(uEngMarks[i],100,25*i+30)
      
      text(uMthMarks[i],200,25*i+30)
     
      text(uSciMarks[i],400,25*i+30)
    }
 
 
}


function updateData()
{
  //save the value of input box in array
  uName[targetSlot] = InpFName.value()
 
  //update target slot value
  targetSlot++
 
  // empty the text box
  InpFName.value("")
  
  //save the value of input box in array
   
   uEngMarks[targetSlot]=InpEngMarks.value()
   uMthMarks[targetSlot]=InpMthMarks.value()
  uSciMarks[targetSlot]=InpSciMarks.value()
  
  
  //empty the text box 
   
  
   InpEngMarks.value("")
    InpMthMarks.value("")
 InpSciMarks.value("")
  
 
 
}